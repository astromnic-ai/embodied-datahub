"""Embodied DataHub CLI - Upload and download robot datasets."""

__version__ = "0.1.0"
